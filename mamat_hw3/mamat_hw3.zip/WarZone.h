#ifndef _WARZONE_H_
#define _WARZONE_H_
#include "defs.h"
#include "List.h"
#include "Squad.h"
#include "WarZone.h"

typedef struct WarZone* PWarZone;



#endif