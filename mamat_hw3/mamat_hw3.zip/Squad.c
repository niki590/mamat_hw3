#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "Squad.h"

typedef struct Squad {
	PLIST sold_List;
	PLIST apc_list;
	int size;
	char *ID;
}SQUAD;
//******************************************************************************
//* function name: Squad_Create 
//* Description : Creates new squad
//* Parameters: copy,free,compare and print functions by pointers for both solider
//*				and apc structs, "1" indicates solider func' and "2" for apc func'
//* Return Value: pointer to the squad 
//******************************************************************************
PSQUAD Squad_Create(char *id, Copy_Function copy1, Free_Function free1, Compare_Function comp1, Print_Func print1,
	Copy_Function copy2, Free_Function free2, Compare_Function comp2, Print_Func print2)
{
	if ((copy1 == NULL) || (free1 == NULL) || (comp1 == NULL) || (print1 == NULL)
		|| (copy2 == NULL) || (free2 == NULL) || (comp2 == NULL) || (print2 == NULL)||(id==NULL))
	{
		printf(ARG_ERR_MSG);
		return NULL;
	}
	PSQUAD squ = (PSQUAD)malloc(sizeof(SQUAD));
	if (squ == NULL)
	{
		printf(MALLOC_ERR_MSG);
		return NULL;
	}
	squ->sold_list = List_Create(copy1, free1, comp1, print1);
	if (squ->sold_list == NULL)
	{
		printf(MALLOC_ERR_MSG);
		return NULL;
	}
	squ->apc_list = List_Create(copy2, free2, comp2, print2);
	if (squ->apc_list == NULL)
	{
		printf(MALLOC_ERR_MSG);
		return NULL;
	}
	squ->ID = (char*)malloc(MAX_ID_LENGTH + 1);
	if (squ->ID == NULL)
	{
		printf(MALLOC_ERR_MSG);
		return NULL;
	}
	strcpy(squ->ID, id);
	squ->size = 0;
	return squ;
}


PSQUAD Squad_Duplicate(PSQUAD Squad) {
	if (Squad == NULL) {
		printf(ARG_ERR_MSG);
		return NULL;
	}
	PLIST Soldiers = Squad_Get_Soldiers(Squad);
	PLIST APCs = Squad_Get_APCs(Squad);
	PSQUAD New_Squad = Squad_Create(Squad->ID, List_Get_Clone_Func(Soldiers), List_Get_Des_Func(Soldiers), List_Get_Cmp_Func(Soldiers), List_Get_Print_Func(Soldiers),
												List_Get_Clone_Func(APCs), List_Get_Des_Func(APCs), List_Get_Cmp_Func(APCs), List_Get_Print_Func(APCs));
	if (New_Squad == NULL) {
		return NULL;
	}
	List_Duplicate(Squad->APCs, New_Squad->APCs);
	List_Duplicate(Squad->Soldiers, New_Squad->Soldiers);
	New_Squad->Count = Squad->Count;
	return New_Squad;
}


/**User Functions**/
void Squad_Print_Func(Element Data) {
	if (Data == NULL) {
		printf(ARG_ERR_MSG);
		return;
	}
	Squad_Print((PSQUAD)Data);
}




