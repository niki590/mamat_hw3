#ifndef _Battlefield_h
#define _Battlefield_h
#include "WarZone.h"

bool Battlefield_SoldExist(PLIST battle, char *sold_id);
bool Battlefield_APCExist(PLIST Battle, char *id);

#endif
