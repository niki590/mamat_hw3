#ifndef _SQUAD_H_
#define _SQUAD_H_
#include "defs.h"
#include "List.h"

typedef SQUAD* PSQUAD;
typedef Element(*Copy_Function)(Element);
typedef void(*Free_Function)(Element);
typedef bool(*Compare_Function)(PKey, PKey);
typedef void(*Print_Func)(Element);







#endif